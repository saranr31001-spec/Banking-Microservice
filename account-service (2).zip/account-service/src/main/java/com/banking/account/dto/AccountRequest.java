package com.banking.account.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class AccountRequest {

    @NotBlank
    private String accountNumber;

    @NotBlank
    private String customerName;

    @Email
    private String email;

    private String phoneNumber;

    @NotBlank
    private String accountType;

    @NotNull
    @DecimalMin("0.0")
    private BigDecimal balance;

    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getAccountType() { return accountType; }
    public void setAccountType(String accountType) { this.accountType = accountType; }

    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }
}
