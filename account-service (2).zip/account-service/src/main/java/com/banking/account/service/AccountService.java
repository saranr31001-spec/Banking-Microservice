package com.banking.account.service;

import com.banking.account.dto.AccountRequest;
import com.banking.account.dto.AccountResponse;
import com.banking.account.exception.ResourceNotFoundException;
import com.banking.account.model.Account;
import com.banking.account.repository.AccountRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountService {

    private final AccountRepository repo;

    public AccountService(AccountRepository repo) {
        this.repo = repo;
    }

    public AccountResponse toResponse(Account a) {
        AccountResponse r = new AccountResponse();
        r.setId(a.getId());
        r.setAccountNumber(a.getAccountNumber());
        r.setCustomerName(a.getCustomerName());
        r.setEmail(a.getEmail());
        r.setPhoneNumber(a.getPhoneNumber());
        r.setAccountType(a.getAccountType());
        r.setBalance(a.getBalance());
        r.setCreatedAt(a.getCreatedAt());
        return r;
    }

    @Transactional(readOnly = true)
    public List<AccountResponse> getAll() {
        return repo.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AccountResponse getById(Long id) {
        Account a = repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Account not found with id " + id));
        return toResponse(a);
    }

    @Transactional
    public AccountResponse create(AccountRequest req) {
        if (repo.existsByAccountNumber(req.getAccountNumber())) {
            throw new IllegalArgumentException("Account number already exists: " + req.getAccountNumber());
        }
        Account a = new Account(req.getAccountNumber(), req.getCustomerName(),
                req.getEmail(), req.getPhoneNumber(), req.getAccountType(), req.getBalance());
        Account saved = repo.save(a);
        return toResponse(saved);
    }

    @Transactional
    public AccountResponse update(Long id, AccountRequest req) {
        Account a = repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Account not found with id " + id));
        a.setAccountNumber(req.getAccountNumber());
        a.setCustomerName(req.getCustomerName());
        a.setEmail(req.getEmail());
        a.setPhoneNumber(req.getPhoneNumber());
        a.setAccountType(req.getAccountType());
        a.setBalance(req.getBalance());
        Account saved = repo.save(a);
        return toResponse(saved);
    }

    @Transactional
    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new ResourceNotFoundException("Account not found with id " + id);
        }
        repo.deleteById(id);
    }
}
