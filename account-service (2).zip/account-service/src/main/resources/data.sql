INSERT INTO accounts (account_number, customer_name, email, phone_number, account_type, balance)
VALUES
('ACC1001', 'John Doe', 'john@example.com', '9876543210', 'SAVINGS', 5000.00),
('ACC1002', 'Alice Smith', 'alice@example.com', '9123456789', 'CURRENT', 25000.00)
ON DUPLICATE KEY UPDATE account_number=account_number;
