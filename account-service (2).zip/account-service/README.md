# Account Service

Standalone Spring Boot Account Service (MySQL)

## MySQL credentials (preconfigured)
- username: root
- password: 123456
- database: accountdb (created automatically by schema.sql)

## How to run
1. Ensure MySQL is running on localhost:3306.
2. Import the project into Eclipse: File → Import → Existing Maven Projects → select project root.
3. Right-click project → Maven → Update Project.
4. Run `com.banking.account.AccountApplication` as Java Application or Spring Boot App.
