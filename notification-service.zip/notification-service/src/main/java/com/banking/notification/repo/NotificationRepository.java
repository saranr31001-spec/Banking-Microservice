package com.banking.notification.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.banking.notification.entity.Notification;

import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUserId(Long userId);

	
	notification.service.Notification save(notification.service.Notification n);

}
