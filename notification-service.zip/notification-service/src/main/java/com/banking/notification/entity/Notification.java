package com.banking.notification.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "notifications")
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Column(columnDefinition = "TEXT")
    private String message;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public Notification() {}

    public Notification(String title, String message, Long userId) {
        this.setTitle(title);
        this.message = message;
        this.userId = userId;
    }

    @PrePersist
    public void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Long getUserId() { return userId; }
    public void setUserId(Long object) { this.userId = object; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

	public List<Notification> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Notification> getByUserId(Long userId2) {
		// TODO Auto-generated method stub
		return null;
	}

	public Notification create(Notification notification) {
		// TODO Auto-generated method stub
		return null;
	}

	public Notification update(Long id2, Notification notification) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(Long id2) {
		// TODO Auto-generated method stub
		
	}

	

		public void setTitle(Object title2) {
		// TODO Auto-generated method stub
		
	}

		public void setMessage(Object message2) {
			// TODO Auto-generated method stub
			
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public void setUserId(Object userId2) {
			// TODO Auto-generated method stub
			
		}

	

	
}
