package notification.service;

import com.banking.notification.repo.NotificationRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class Notification {

    private final NotificationRepository repo;

    public Notification(NotificationRepository repo) {
        this.repo = repo;
    }

    public List<com.banking.notification.entity.Notification> getAll() {
        return repo.findAll();
    }

    public List<com.banking.notification.entity.Notification> getByUserId(Long userId) {
        return repo.findByUserId(userId);
    }

    public Notification create(Notification n) {
        return repo.save(n);
    }

    public com.banking.notification.entity.Notification update(Long id, Notification n) {
        com.banking.notification.entity.Notification existing = repo.findById(id).orElseThrow(() -> new RuntimeException("Notification not found"));
        existing.setTitle(n.getTitle());
        existing.setMessage(n.getMessage());
        existing.setUserId(n.getUserId());
        return repo.save(existing);
    }

    @SuppressWarnings("unused")
	private void setMessage(Object message) {
		// TODO Auto-generated method stub
		
	}

	private Object getUserId() {
		// TODO Auto-generated method stub
		return null;
	}

	private Object getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	private Object getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(Long id) {
        repo.deleteById(id);
    }
}
