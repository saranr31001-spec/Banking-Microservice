package com.banking.auth;

import org.springframework.stereotype.Component;

@Component
public class JwtUtil {

    public String generate(String username) {
        return "JWT-TOKEN-FOR-" + username;
    }
}
