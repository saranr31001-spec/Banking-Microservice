package com.banking.transaction.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.banking.transaction.entity.Transaction;
import com.banking.transaction.repo.TransactionRepository;

@Service
public class TransactionService {

    private final TransactionRepository repository;

    public TransactionService(TransactionRepository repository) {
        this.repository = repository;
    }

    // GET all transactions
    public List<Transaction> getAllTransactions() {
        return repository.findAll();
    }

    // GET transaction by ID
    public Optional<Transaction> getTransactionById(Long id) {
        return repository.findById(id);
    }

    // CREATE a new transaction
    public Transaction createTransaction(Transaction transaction) {
        return repository.save(transaction);
    }

    // UPDATE an existing transaction
    public Transaction updateTransaction1(Long id, Transaction transactionDetails) {
        Transaction transaction = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Transaction not found with id " + id));

        transaction.setAccountNumber(transactionDetails.getAccountNumber());
        transaction.setFromAccountId(transactionDetails.getFromAccountId());
        transaction.setToAccountId(transactionDetails.getToAccountId());
        transaction.setAmount(transactionDetails.getAmount());
        transaction.setTransactionType(transactionDetails.getTransactionType());
        transaction.setDescription(transactionDetails.getDescription());
        transaction.setTransactionDate(transactionDetails.getTransactionDate());
        transaction.setStatus(transactionDetails.getStatus());

        return repository.save(transaction);
    }

    // DELETE a transaction
    public void deleteTransaction(Long id) {
        Transaction transaction = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Transaction not found with id " + id));
        repository.delete(transaction);
    }

	public Transaction updateTransaction(Long id, Transaction transaction) {
		// TODO Auto-generated method stub
		return null;
	}

	public Optional<Transaction> getTransactionById1(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Transaction createTransaction1(Transaction transaction) {
		// TODO Auto-generated method stub
		return null;
	}
}
