package com.banking.transaction.entity;

public enum TransactionType {
    CREDIT,
    DEBIT
}
